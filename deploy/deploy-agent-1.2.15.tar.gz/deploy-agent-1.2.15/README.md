Deploy-agent is a python script runs on every host and execute deploy scripts.
See https://github.com/pinterest/teletraan/wiki for more details.

To run unit tests
> tox
